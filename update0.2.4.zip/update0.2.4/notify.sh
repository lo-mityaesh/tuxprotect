#!/bin/bash



notify-send "Hello World"